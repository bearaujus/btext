# Latest Changelog
Release Date : 12/23/2020 `Version 1.0`

> + Initial Commit

# Older Changelog
-

# Credit
+ Main Github Page : [https://github.com/haryobagas/](https://github.com/haryobagas/)
+ Linkedin : [https://www.linkedin.com/in/haryobagas08/](https://www.linkedin.com/in/haryobagas08/)

**Bear Au Jus - ジュースとくま** @2020